#!/usr/bin/env python3
"""
Author: Shaanan Cohney

toy_llm_generate_input.py

Generates a small, human-understandable Assignment 1 input file from text.
This is NOT used for grading; it is only for student understanding/testing.

Design goals:
- deterministic output (no randomness)
- no third-party dependencies
- simple tokenisation (split on whitespace, strip basic punctuation)
- tiny "embedding table" derived from token string hashing
"""

from __future__ import annotations

import argparse
import hashlib
import re
import sys
from typing import List, Tuple


def _tokenize(text: str) -> List[str]:
    # Gentle, predictable tokenisation: lowercase, keep apostrophes in words,
    # strip other punctuation, split on whitespace.
    text = text.lower()
    text = re.sub(r"[^a-z0-9'\n\t ]+", " ", text)
    tokens = [t for t in text.split() if t]
    return tokens


def _hash_to_unit_interval(seed: str) -> float:
    # Deterministic float in [0, 1).
    h = hashlib.sha256(seed.encode("utf-8")).digest()
    x = int.from_bytes(h[:8], "big")
    return (x % (10**12)) / float(10**12)


def _embed_token(token: str, d: int) -> List[float]:
    # Deterministic, small-ish values in roughly [-1, 1].
    vec: List[float] = []
    for i in range(d):
        u = _hash_to_unit_interval(f"{token}|{i}")
        vec.append(2.0 * u - 1.0)
    return vec


_PRONOUNS = {
    "i",
    "me",
    "you",
    "he",
    "him",
    "she",
    "her",
    "it",
    "we",
    "us",
    "they",
    "them",
    "my",
    "your",
    "his",
    "hers",
    "its",
    "our",
    "their",
}

_COMMON_VERBS = {
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    "have",
    "has",
    "had",
    "do",
    "does",
    "did",
    "say",
    "says",
    "said",
    "go",
    "goes",
    "went",
    "make",
    "made",
    "give",
    "gave",
    "take",
    "took",
    "get",
    "got",
    "see",
    "saw",
    "know",
    "knew",
    "think",
    "thought",
}

_STOPWORDS = {
    "the",
    "a",
    "an",
    "and",
    "or",
    "but",
    "to",
    "of",
    "in",
    "on",
    "at",
    "with",
    "for",
    "from",
    "as",
    "by",
    "that",
    "this",
    "these",
    "those",
}


def _is_verbish(token: str) -> bool:
    if token in _COMMON_VERBS:
        return True
    return token.endswith("ed") or token.endswith("ing")


def _structured_embeddings(
    tokens: List[str],
    d: int,
    max_entities: int | None = None,
) -> Tuple[List[List[float]], List[str]]:
    """
    Build embeddings that are intentionally interpretable.

    Dimensions (if available):
    - dim0: bias = 1.0 (helps avoid all-zero vectors)
    - dim1: noun-ish flag
    - dim2: verb-ish flag
    - dim3: pronoun flag
    - dim4..: entity one-hot (for a small number of noun tokens)

    Heuristic entity assignment:
    - when a new noun token appears, assign it the next entity slot (up to max_entities)
    - pronouns copy the most recent entity slot (simple "last noun" heuristic)
    """
    if max_entities is None:
        max_entities = max(0, d - 4)
    max_entities = max(0, min(max_entities, max(0, d - 4)))

    entity_slots: dict[str, int] = {}
    entity_names: List[str] = []
    last_entity_slot: int | None = None

    out: List[List[float]] = []

    for tok in tokens:
        vec = [0.0] * d
        if d >= 1:
            vec[0] = 1.0

        is_pronoun = tok in _PRONOUNS
        is_stop = tok in _STOPWORDS
        is_verb = _is_verbish(tok)

        # Treat as noun-ish if it's not a stopword and not a pronoun and not verb-ish.
        is_noun = (not is_stop) and (not is_pronoun) and (not is_verb)

        if d >= 2 and is_noun:
            vec[1] = 1.0
        if d >= 3 and is_verb:
            vec[2] = 1.0
        if d >= 4 and is_pronoun:
            vec[3] = 1.0

        # Entity slots (only if we have space).
        if max_entities > 0 and d >= 5:
            if is_noun:
                if tok not in entity_slots and len(entity_slots) < max_entities:
                    slot = len(entity_slots)
                    entity_slots[tok] = slot
                    entity_names.append(tok)
                if tok in entity_slots:
                    slot = entity_slots[tok]
                    vec[4 + slot] = 2.0
                    last_entity_slot = slot
            elif is_pronoun and last_entity_slot is not None:
                vec[4 + last_entity_slot] = 2.0

        out.append(vec)

    return out, entity_names


def _make_matrix(name: str, d: int) -> List[List[float]]:
    # Deterministic "parameter" matrix, roughly [-0.5, 0.5].
    mat: List[List[float]] = []
    for r in range(d):
        row: List[float] = []
        for c in range(d):
            u = _hash_to_unit_interval(f"{name}|{r}|{c}")
            row.append(u - 0.5)
        mat.append(row)
    return mat


def _identity_matrix(d: int) -> List[List[float]]:
    return [[1.0 if r == c else 0.0 for c in range(d)] for r in range(d)]


def _format_row(values: List[float]) -> str:
    # Input file accepts general floats; keep it readable.
    return " ".join(f"{v:.6f}" for v in values)


def _split_prompt_and_gen(tokens: List[str], n: int, g: int) -> Tuple[List[str], List[str]]:
    prompt = tokens[:n]
    gen = tokens[n : n + g]
    if len(prompt) < n:
        raise ValueError(f"Need at least n={n} tokens, got {len(tokens)}")
    if len(gen) < g:
        raise ValueError(f"Need at least n+g={n+g} tokens, got {len(tokens)}")
    return prompt, gen


def main(argv: List[str]) -> int:
    parser = argparse.ArgumentParser(description="Generate a toy COMP10002 A1 2026 input file.")
    parser.add_argument("--n", type=int, default=6, help="prompt token count (<=64)")
    parser.add_argument("--g", type=int, default=2, help="generated token count (<=32)")
    parser.add_argument("--d", type=int, default=4, help="embedding dimension (<=16)")
    parser.add_argument(
        "--mode",
        choices=["hash", "structured"],
        default="hash",
        help="how to generate embeddings/matrices: 'hash' (random-looking) or 'structured' (interpretable)",
    )
    parser.add_argument(
        "--mask",
        default=None,
        help="optional prompt mask like '1 1 1 1 0 0' (length n). Default: all ones.",
    )
    parser.add_argument("--text", default=None, help="text to tokenise; if omitted, read stdin")
    parser.add_argument(
        "--show-tokens",
        action="store_true",
        help="print token list to stderr for reference",
    )
    args = parser.parse_args(argv)

    if not (1 <= args.n <= 64 and 0 <= args.g <= 32 and 1 <= args.d <= 16):
        raise ValueError("Must satisfy: 1<=n<=64, 0<=g<=32, 1<=d<=16")

    text = args.text if args.text is not None else sys.stdin.read()
    tokens = _tokenize(text)
    prompt_tokens, gen_tokens = _split_prompt_and_gen(tokens, args.n, args.g)

    if args.show_tokens:
        print("Prompt tokens:", prompt_tokens, file=sys.stderr)
        print("Gen tokens:", gen_tokens, file=sys.stderr)

    if args.mask is None:
        mask = [1] * args.n
    else:
        mask = [int(x) for x in args.mask.split()]
        if len(mask) != args.n or any(x not in (0, 1) for x in mask):
            raise ValueError("--mask must be n integers of 0/1")

    if args.mode == "hash":
        prompt = [_embed_token(tok, args.d) for tok in prompt_tokens]
        gen = [_embed_token(tok, args.d) for tok in gen_tokens]
        wq = _make_matrix("Wq", args.d)
        wk = _make_matrix("Wk", args.d)
        wv = _make_matrix("Wv", args.d)
    else:
        full = prompt_tokens + gen_tokens
        full_emb, entity_names = _structured_embeddings(full, args.d)
        prompt = full_emb[: args.n]
        gen = full_emb[args.n :]
        wq = _identity_matrix(args.d)
        wk = _identity_matrix(args.d)
        wv = _identity_matrix(args.d)
        if args.show_tokens:
            print("Structured mode entity slots:", entity_names, file=sys.stderr)

    print(f"{args.n} {args.d} {args.g}")
    print(" ".join(str(x) for x in mask))
    for row in prompt:
        print(_format_row(row))
    for row in gen:
        print(_format_row(row))
    for row in wq:
        print(_format_row(row))
    for row in wk:
        print(_format_row(row))
    for row in wv:
        print(_format_row(row))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
